//
//  TileModel.m
//  SampleTic
//
//  Created by tcs on 5/11/13.
//  Copyright (c) 2013 tcs. All rights reserved.
//

#import "TileModel.h"

@implementation TileModel


@synthesize count =_count;
@synthesize turnCount =_turnCount;

@end
