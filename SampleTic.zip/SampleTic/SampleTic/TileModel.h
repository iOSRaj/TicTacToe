//
//  TileModel.h
//  SampleTic
//
//  Created by tcs on 5/11/13.
//  Copyright (c) 2013 tcs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TileModel : NSObject

@property(nonatomic)int count; //total count of tiles
@property(nonatomic)int turnCount; // total no. of tapable counts
@end
